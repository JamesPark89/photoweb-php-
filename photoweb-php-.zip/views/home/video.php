<!DOCTYPE html>
<html>
  <head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <?php include '../partials/head.php';?>
  </head>
  <body>
  <?php include '../partials/nav.php';?>
    <div class="title d-flex justify-content-center">
      <span>Video</span>
    </div>
    <div class="videobox">
      <p align="center">
        <iframe
          
          src="https://www.youtube.com/embed/DLxWMWWiADM"
          allowfullscreen
        >
        </iframe>
      </p>
      <p align="center">
        <iframe
          src="https://www.youtube.com/embed/mFhY3KU3wE0"
          allowfullscreen
        >       
      </iframe>
      </p>
      <p align="center">
        <iframe
          src="https://www.youtube.com/embed/ebP8uDW-eiQ"
          allowfullscreen
        >
        </iframe>
</p>
      <p align="center">
        <iframe
          src="https://www.youtube.com/embed/9ERm_UxfeNk"
          allowfullscreen
        >
      </iframe>
      </p>
    </div>
  </body>
  <!-- footer -->
  <?php include '../partials/footer.php';?>
</html>
